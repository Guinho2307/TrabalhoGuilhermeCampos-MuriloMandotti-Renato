package com.example.trab.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.trab.R;

public class GerenciarProdutoActivity extends AppCompatActivity {


    private Spinner spProduto;
    private EditText edValUnitario;
    private EditText edQuantidadeItens;
    private Button btVoltar;
    private Button btSalvarItens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerenciar_produto);

        spProduto = findViewById(R.id.SpProduto);
        edValUnitario = findViewById(R.id.edValUnitario);
        edQuantidadeItens = findViewById(R.id.edQuantidadeItens);
        btVoltar = findViewById(R.id.btVoltar);
        btSalvarItens = findViewById(R.id.btSalvarItens);


        btSalvarItens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarAlteracoes();
            }
        });


        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(MainActivity.class);
            }

        });
    }

    private void salvarAlteracoes() {

        String novoValorUnitario = edValUnitario.getText().toString();
        String novaQuantidade = edQuantidadeItens.getText().toString();


    }
    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(GerenciarProdutoActivity.this,
                activity);
        startActivity(intent);
    }
}