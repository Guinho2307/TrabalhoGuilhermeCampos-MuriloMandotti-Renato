package com.example.trab.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trab.R;
import com.example.trab.adapter.ItemAdapter;
import com.example.trab.controller.ItemController;
import com.example.trab.model.Item;

import java.util.ArrayList;
import java.util.Random;

public class CadastrarItemActivity extends AppCompatActivity {

    private EditText edNomeItem;
    private EditText edQuantidade;
    private EditText edValorItem;
    private TextView tvRetornarCodItem;
    private Button btSalvarItem;
    private RecyclerView ltItensCadastrados;
    private AlertDialog cadastroDialog;
    private ItemController controller;

    private Button btVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_item);

        edQuantidade = findViewById(R.id.edQuantidade);
        edNomeItem = findViewById(R.id.edNomeItem);
        edValorItem = findViewById(R.id.edValorItem);
        tvRetornarCodItem = findViewById(R.id.tvRetornarCodItem);
        btSalvarItem = findViewById(R.id.btSalvarItem);
        ltItensCadastrados = findViewById(R.id.ltItensCadastrados);
        btVoltar = findViewById(R.id.btVoltar);
        controller = new ItemController(this);

        btSalvarItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SalvarItem();
            }
        });

        atualizarListaItens();
        geradorCodigo();

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(MainActivity.class);
            }
        });
    }

    private void geradorCodigo() {
        int codigo = new Random().nextInt(100);
        tvRetornarCodItem.setText("Código do Item:" + codigo);
    }

    private void atualizarListaItens() {
        ArrayList<Item> listaItens = controller.retornaItems();
        ItemAdapter adapter = new ItemAdapter(this, R.layout.activity_list_item, listaItens);
        ltItensCadastrados.setAdapter(adapter);
    }

    private void SalvarItem() {
        String codigoText = tvRetornarCodItem.getText().toString();

        int posicaoNumerica = codigoText.lastIndexOf(':') + 1;

        int codigo = Integer.parseInt(codigoText.substring(posicaoNumerica).trim());

        String retorno = controller.salvarItem(
                edNomeItem.getText().toString(),
                codigo,
                Double.parseDouble(edValorItem.getText().toString()),
                Integer.parseInt(edQuantidade.getText().toString())
        );

        if (retorno != null) {
            if (retorno.contains("Nome do Item")) {
                edNomeItem.setError(retorno);
                edNomeItem.requestFocus();
            } else if (retorno.contains("Valor")) {
                edValorItem.setError(retorno);
                edValorItem.requestFocus();
            } else if (retorno.contains("Quantidade")) {
                edQuantidade.setError(retorno);
                edQuantidade.requestFocus();
            } else if (retorno.contains("Código")) {
                tvRetornarCodItem.setError(retorno);
                tvRetornarCodItem.requestFocus();
            } else {
                Toast.makeText(this, retorno, Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Item cadastrado com sucesso!", Toast.LENGTH_LONG).show();
            if (cadastroDialog != null) {
                cadastroDialog.show();
            }
        }
    }

    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(CadastrarItemActivity.this, activity);
        startActivity(intent);
    }
}
