package com.example.trab.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trab.R;
import com.example.trab.model.Item;
import com.example.trab.view.CadastrarItemActivity;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private ArrayList<Item> itemList;
    private Context context;
    private int activityListItem;

    public ItemAdapter(CadastrarItemActivity context, int activityListItem, ArrayList<Item> listaItens) {
        this.context = context;
        this.activityListItem = activityListItem;
        this.itemList = listaItens;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(activityListItem, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item currentItem = itemList.get(position);


        holder.nomeItem.setText(currentItem.getNomeItem());
        holder.codigoItem.setText(currentItem.getCodigo());
        holder.quantidadeItem.setText(String.valueOf(currentItem.getQuantidade()));
        holder.valorItem.setText(String.valueOf(currentItem.getValorUnitario()));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        public TextView nomeItem, codigoItem, quantidadeItem, valorItem;

        public ItemViewHolder(View itemView) {
            super(itemView);
            nomeItem = itemView.findViewById(R.id.nomeItem);
            codigoItem = itemView.findViewById(R.id.codigoItem);
            quantidadeItem = itemView.findViewById(R.id.quantidadeItem);
            valorItem = itemView.findViewById(R.id.valorItem);
        }
    }
}
