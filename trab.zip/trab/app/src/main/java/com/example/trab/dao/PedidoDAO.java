package com.example.trab.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import com.example.trab.helper.SQLiteDataHelper;
import com.example.trab.model.Pedido;

public class PedidoDAO {
    private static PedidoDAO instancia;
    private SQLiteDatabase db;
    private SQLiteDataHelper dbHelper;

    private PedidoDAO(Context context) {
        dbHelper = new SQLiteDataHelper(context, "nome_do_seu_banco_de_dados.db", null, 1);
    }

    public static PedidoDAO getInstancia(Context context) {
        if (instancia == null) {
            instancia = new PedidoDAO(context);
        }
        return instancia;
    }

    public void insert(Pedido pedido) {
        try {
            db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("NOME_CLIENTE", pedido.getNomeCliente());
            values.put("VALOR_TOTAL", pedido.getValorTotal());


            db.insert("PEDIDO", null, values);
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Pedido> getAll() {
        ArrayList<Pedido> listaPedidos = new ArrayList<>();
        try {
            db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT ID, NOME_CLIENTE, VALOR_TOTAL FROM PEDIDO", null);

            if (cursor.moveToFirst()) {
                do {
                    Pedido pedido = new Pedido();
                    pedido.setId(cursor.getInt(0));
                    pedido.setNomeCliente(cursor.getString(1));
                    pedido.setValorTotal(cursor.getDouble(2));


                    listaPedidos.add(pedido);
                } while (cursor.moveToNext());
            }

            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaPedidos;
    }

    public Pedido getByCliente(String nomeCliente) {
        Pedido pedido = null;
        try {
            db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT ID, NOME_CLIENTE, VALOR_TOTAL FROM PEDIDO WHERE NOME_CLIENTE = ?",
                    new String[]{nomeCliente});

            if (cursor.moveToFirst()) {
                pedido = new Pedido();
                pedido.setId(cursor.getInt(0));
                pedido.setNomeCliente(cursor.getString(1));
                pedido.setValorTotal(cursor.getDouble(2));


                cursor.close();
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pedido;
    }
}
