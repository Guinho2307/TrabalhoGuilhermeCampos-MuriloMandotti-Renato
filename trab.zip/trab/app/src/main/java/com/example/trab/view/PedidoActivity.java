package com.example.trab.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.trab.R;
import com.example.trab.adapter.ItemSpinnerAdapter;
import com.example.trab.controller.ItemController;
import com.example.trab.model.Item;

import java.util.ArrayList;

public class PedidoActivity extends AppCompatActivity {

    private TextView tvErroItem;
    private Spinner spVenda;
    private EditText edQuantidadeProd;

    private ImageButton btAddProduto;
    private TextView tvInfoProd;

    private TextView tvQtdProd;

    private TextView tvValorTotal;

    private Button btVoltarVenda;

    private Button btVenderProd;


    private ArrayList<Item> itemList;

    private Button btNF;

    private int posicaoSelecionada = 0;

    private ItemController controller;

    private double valorTotalPedido = 0.0;
    private int quantidadeTotalItens = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);
        controller = new ItemController(this);

        spVenda = findViewById(R.id.spVenda);
        edQuantidadeProd = findViewById(R.id.edQuantidadeProd);
        tvInfoProd = findViewById(R.id.tvInfoProd);
        tvQtdProd = findViewById(R.id.tvQtdProd);
        tvValorTotal = findViewById(R.id.tvValorTotal);
        btVoltarVenda = findViewById(R.id.btVoltarVenda);
        btVenderProd = findViewById(R.id.btVenderProd);
        btNF = findViewById(R.id.btNF);
        btAddProduto = findViewById(R.id.btAddProduto);
        tvErroItem = findViewById(R.id.tvErroItem);

        itemList = controller.retornaItems();

        if (!itemList.isEmpty()) {

            Item itemPadrao = new Item();
            itemPadrao.setNomeItem("Selecione um item");
            itemList.add(0, itemPadrao);

            ItemSpinnerAdapter adapter = new ItemSpinnerAdapter(this, R.layout.item_spinner_layout, itemList);
            spVenda.setAdapter(adapter);
        }

        btVoltarVenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(MainActivity.class);
            }
        });

        btNF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PedidoActivity.this, EmitirNfActivity.class);
                intent.putExtra("VALOR TOTAL DO PEDIDO", valorTotalPedido);
                intent.putExtra("QUANTIDADE TOTAL DE ITENS", quantidadeTotalItens);
                startActivity(intent);
            }
        });

        spVenda.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int posicao, long l) {
                if (posicao > 0) {
                    tvErroItem.setVisibility(View.GONE);
                    posicaoSelecionada = posicao;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btAddProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarPedido();
            }
        });
    }

    private void salvarPedido() {
        double valorTotal = 0.0;
        double quantidade = 0.0;

        if (edQuantidadeProd.getText().toString().isEmpty()) {
            edQuantidadeProd.setError("Informe a quantidade de produtos!");
            edQuantidadeProd.requestFocus();
            return;
        } else {
            quantidade = Double.parseDouble(edQuantidadeProd.getText().toString());
            if (quantidade <= 0) {
                edQuantidadeProd.setError("A quantidade de itens deve ser maior que zero!");
                edQuantidadeProd.requestFocus();
                return;
            }
        }

        if (posicaoSelecionada == 0) {
            tvErroItem.setVisibility(View.VISIBLE);
            return;
        }

        Item itemSelecionado = controller.retornaItems().get(posicaoSelecionada - 1);

        valorTotal = quantidade * itemSelecionado.getValorUnitario();

        tvValorTotal.setText(String.valueOf(valorTotal));
    }

    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(PedidoActivity.this, activity);
        startActivity(intent);
    }
}