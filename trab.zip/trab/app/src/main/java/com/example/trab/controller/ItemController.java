package com.example.trab.controller;

import android.content.Context;

import com.example.trab.dao.ItemDAO;

import com.example.trab.model.Item;

import java.util.ArrayList;

public class ItemController {
    private Context context;

    public ItemController(Context context) {
        this.context = context;
    }

    public String salvarItem(String nomeItem, int codigo, double valorUnitario, int quantidade) {
        try {
            if (nomeItem.isEmpty()) {
                return "Informe o Nome do Item!";
            }
            if (valorUnitario < 0) {
                return "Informe o Valor do Item";
            }
            if (quantidade < 0) {
                return "Informe a Quantidade do Item";
            }

            Item item = ItemDAO.getInstancia(context).getById(codigo);

            if (item != null) {
                return "O Código (" + codigo + ") já está cadastrado!";
            } else {
                item = new Item();
                item.setNomeItem(nomeItem);
                item.setCodigo(codigo);
                item.setQuantidade(quantidade);
                item.setValorUnitario(valorUnitario);

                ItemDAO.getInstancia(context).insert(item);
            }
        } catch (Exception ex) {
            // Ele imprime no console a rastreabilidade da pilha (stack trace) do ponto onde é chamado.
            //utilizei para saber onde tava um erro que não achava
            ex.printStackTrace();
            return "Erro ao gravar Item: " + ex.getMessage();
        }
        return null;
    }

    public ArrayList<Item> retornaItems() {
        return ItemDAO.getInstancia(context).getAll();
    }
}