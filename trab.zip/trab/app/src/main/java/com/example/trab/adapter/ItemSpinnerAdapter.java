package com.example.trab.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.trab.model.Item;
import com.example.trab.R;
import java.util.ArrayList;

public class ItemSpinnerAdapter extends ArrayAdapter<Item> {

    private ArrayList<Item> itemList;

    public ItemSpinnerAdapter(Context context, int resource, ArrayList<Item> itemList) {
        super(context, resource, itemList);
        this.itemList = itemList;
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Item getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.item_spinner_layout, null);
        }

        Item item = itemList.get(position);

        if (item != null) {
            TextView itemName = view.findViewById(R.id.itemNameTextView);
            if (itemName != null) {
                itemName.setText(item.getNomeItem());
            }
        }

        return view;
    }
}