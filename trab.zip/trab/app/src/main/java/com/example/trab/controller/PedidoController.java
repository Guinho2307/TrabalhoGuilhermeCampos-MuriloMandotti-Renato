package com.example.trab.controller;

import android.content.Context;
import com.example.trab.dao.PedidoDAO;
import com.example.trab.model.Pedido;
import java.util.ArrayList;

public class PedidoController {
    private Context context;

    public PedidoController(Context context) {
        this.context = context;
    }

    public String salvarPedido(String nomeCliente, double valorTotal) {
        try {
            if (nomeCliente.isEmpty()) {
                return "Informe o Nome do Cliente!";
            }
            if (valorTotal < 0) {
                return "Informe o Valor Total do Pedido";
            }


            Pedido pedido = PedidoDAO.getInstancia(context).getByCliente(nomeCliente);

            if (pedido != null) {
                return "Já existe um pedido cadastrado para este cliente!";
            } else {
                pedido = new Pedido();
                pedido.setNomeCliente(nomeCliente);
                pedido.setValorTotal(valorTotal);

                PedidoDAO.getInstancia(context).insert(pedido);
            }
        } catch (Exception ex) {

            // Ele imprime no console a rastreabilidade da pilha (stack trace) do ponto onde é chamado.
            //usei para saber como estava com erro
            ex.printStackTrace();
            return "Erro ao gravar Pedido: " + ex.getMessage();
        }
        return null;
    }

    public ArrayList<Pedido> retornaPedidos() {
        return PedidoDAO.getInstancia(context).getAll();
    }
}
