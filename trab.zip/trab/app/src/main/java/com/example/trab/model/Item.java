package com.example.trab.model;

public class Item {

    private String NomeItem;
    private int Codigo;
    private Double ValorUnitario;
    private Integer Quantidade;


    public Item() {

    }

    public Item(String nomeItem, int codigo, Double valorUnitario, Integer quantidade) {
        NomeItem = nomeItem;
        Codigo = codigo;
        ValorUnitario = valorUnitario;
        Quantidade = quantidade;
    }

    public String getNomeItem() {
        return NomeItem;
    }

    public void setNomeItem(String nomeItem) {
        NomeItem = nomeItem;
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int codigo) {
        Codigo = codigo;
    }

    public Double getValorUnitario() {
        return ValorUnitario;
    }

    public void setValorUnitario(Double valorUnitario) {
        ValorUnitario = valorUnitario;
    }

    public Integer getQuantidade() {
        return Quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        Quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "Item{" +
                "NomeItem='" + NomeItem + '\'' +
                ", Codigo=" + Codigo +
                ", ValorUnitario=" + ValorUnitario +
                ", Quantidade=" + Quantidade +
                '}';
    }
}
