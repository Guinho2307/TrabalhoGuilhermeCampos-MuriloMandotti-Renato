package com.example.trab.view;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.trab.R;

public class MainActivity extends Activity {
    private Button btCadastrarItens;

    private Button btPedido;

    private Button  btEmitirNf;

    private Button btGerenciarProduto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btCadastrarItens = findViewById(R.id.btCadastrarItens);
        btEmitirNf = findViewById(R.id.btEmitirNf);
        btPedido = findViewById(R.id.btPedido);
        btGerenciarProduto = findViewById(R.id.btGerenciarProduto);

        btGerenciarProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(GerenciarProdutoActivity.class);
            }
        });
        btCadastrarItens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {abrirActivity(CadastrarItemActivity.class);
            }
        });
        btEmitirNf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(EmitirNfActivity.class);
            }
        });
        btPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(PedidoActivity.class);
            }
        });
    }

    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(MainActivity.this,
                activity);
        startActivity(intent);
    }
}
