package com.example.trab.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.example.trab.model.Item;
import com.example.trab.helper.SQLiteDataHelper;

import java.util.ArrayList;

public class ItemDAO  implements GenericDao<Item>{

    private SQLiteOpenHelper openHelper;


    private SQLiteDatabase bd;


    private String nomeTabela = "ITEM";


    private String[]colunas = {"NOMEITEM", "CODIGO","QUANTIDADE","VALOR"};

    private Context context;

    private static ItemDAO instancia;



    public static ItemDAO getInstancia(Context context) {
        if (instancia == null) {
            instancia = new ItemDAO(context);
        }
        return instancia;
    }
    private ItemDAO(Context context) {
            this.context = context;





        openHelper = new SQLiteDataHelper(this.context, "UNIPAR_BD",
                null, 1);

        bd = openHelper.getWritableDatabase();
    }

    @Override
    public long insert(Item obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getNomeItem());
            valores.put(colunas[1], obj.getCodigo());
            valores.put(colunas[2], obj.getQuantidade());
            valores.put(colunas[3], obj.getValorUnitario());

            return bd.insert(nomeTabela, null, valores);

        }catch (SQLException ex){
            Log.e("ERRO", "ItemDAO.insert(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Item obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getNomeItem());

            String[]identificador = {String.valueOf(obj.getCodigo())};
            return bd.update(nomeTabela, valores,
                    colunas[0]+" = ?", identificador);


        }catch (SQLException ex){
            Log.e("ERRO", "ItemDAO.update(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Item obj) {
        try{

            String[]identificador = {String.valueOf(obj.getCodigo())};
            return bd.delete(nomeTabela, colunas[0]+" = ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("ERRO", "ItemDAO.delete(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Item> getAll() {
        ArrayList<Item> lista = new ArrayList<>();
        try{
            Cursor cursor = bd.query(nomeTabela, colunas,
                    null, null, null,
                    null, colunas[0]);


            if(cursor.moveToFirst()){
                do{
                    Item item = new Item();
                    item.setNomeItem(cursor.getString(0));
                    item.setCodigo(cursor.getInt(1));
                    item.setQuantidade(cursor.getInt(2));
                    item.setValorUnitario(cursor.getDouble(3));


                    lista.add(item);

                }while (cursor.moveToNext());
            }
        }catch (SQLException ex){
            Log.e("ERRO", "ItemDAO.getAll(): "+ex.getMessage());
        }
        return lista;
    }

    @Override
    public Item getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = bd.query(nomeTabela, colunas,
                    colunas[0]+" = "+id, null,
                    null, null, null);


            if(cursor.moveToFirst()){
                Item item = new Item();
                item.setNomeItem(cursor.getString(0));
                item.setCodigo(cursor.getInt(1));
                item.setQuantidade(cursor.getInt(2));
                item.setValorUnitario(cursor.getDouble(3));

                return item;
            }

        }catch (SQLException ex){
            Log.e("ERRO", "ItemDAO.getById(): "+ex.getMessage());
        }

        return null;
    }
}
