package com.example.trab.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.example.trab.R;

import java.util.Random;

public class EmitirNfActivity extends AppCompatActivity {

    private TextView tvCodBarras;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emitir_nf);
        tvCodBarras = findViewById(R.id.tvCodBarras);
        geradorCodigo();
        ;

        Intent intent = getIntent();
        double valorTotalPedido = intent.getDoubleExtra("VALOR_TOTAL_PEDIDO", 0.0);
        int quantidadeTotalItens = intent.getIntExtra("QUANTIDADE_TOTAL_ITENS", 0);


    }

    private void geradorCodigo() {
        int codigo = new Random().nextInt(1000000000);
        tvCodBarras.setText("Código do Item:" +codigo);
    }



    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(EmitirNfActivity.this,
                activity);
        startActivity(intent);
    }
}